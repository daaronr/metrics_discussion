setwd("C:/Users/gk249/Downloads/Bayesian workshop/Data and codes")
library(rjags)
library(MCMCpack)
data(birthwt)



probit.data<-list(
"n"=nrow(birthwt),
"y"=birthwt$low, 
"x"=birthwt$smoke)


probit.parameters<-c(
"beta"
)


set.seed(1982)
probit.inits<-function() {
list(
beta=rnorm(2)
)
}




jags.probit <- jags.model( file = "probit.bug", 
	data=probit.data, inits=probit.inits, n.chains=1, n.adapt=500 )


probit <- coda.samples( jags.probit, probit.parameters, n.iter=10000 )


summary(probit)



